<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOMEPAGE</title>
    <script src="https://kit.fontawesome.com/a2dff4940e.js" crossorigin="anonymous"></script>
</head>
<link rel="stylesheet" href="homepage.css">
<link rel="stylesheet" href="<script src="https://kit.fontawesome.com/a2dff4940e.js" crossorigin="anonymous"></script>"
<style>
    *{ margin: 0; padding: 0;}

    .centerdiv{

        display: flex;
        justify-content: center;
        align-items: flex-start;
    }
    #footer {
    
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #4e4e50;
    color: white;
    text-align: center;
    margin-top: 10px;
}
body{
    margin-bottom: 100px;
    background: linear-gradient(#1a1a1d,#6f2232);
}
.font{
    font-size: 20px;
}
.center{
    font-size: 25px;
}

    .her{
        height: 100px;
        width: 100px;
        background-color: #f5f6fa;
        border-radius: 50px;
        text-align: center;
        line-height: 125px;
        margin: 10px;
        box-shadow: 2px 5px 3px 3px #dcdde1;
        
    }
    a i{
        transition: all 0.3s linear;
    }

    a:hover i{
        transform: scale(1.4);
    }
    
    .fa-instagarm{
        color: #e84393;
    }
    .fa-facebook{
        color:#3b5998;
    }
    
    .fa-youtube{
        color: #BB001B;
    }
    .fa-envelope{
        color:#BB001B;
    }
    


    body{
    background-color: black;
}
h1{
    background-color: #c3073f;
    padding: 10px;
    margin-left: 100px;
    margin-right: 100px;
    border-bottom-left-radius: 40px;
    border-bottom-right-radius: 40px;
    text-align: center;
    font-size: 45px;
    color: whitesmoke;
    font-family: 'New Tegomin', serif;
}
h2{
    background-color: #c3073f;
    padding: 10px;
    margin-left: 75px;
    margin-right: 75px;
    border-bottom-left-radius: 40px;
    border-bottom-right-radius: 40px;
    font-family: 'New Tegomin', serif;
    font-size: 45px;
    text-align: center;
    color: whitesmoke;
}
h3{
    
    text-align: left;
    font-size: 25px; 
    color: whitesmoke;
}
h4{
    
    text-align: left;
    font-size: 15px; 
    color:whitesmoke;
}
img{
    width: 50%;
    
    float: centre;
    justify-content: center;
    display: block;
    margin-left: auto;
    margin-right: auto;

    
    font-size: 40px;
    text-align: center;
}
#you{
   font-size: 45px; 
   text-align: left;
}
#me{
    width: 500px;
    height: auto;
    float: left; 
}
#she{
    width: 475px;
    height: auto;
    float: right; 
} 
footer {
    text-align: center;
    padding: 3px;
    
    color: whitesmoke;
  } 
figcaption{
    color: whitesmoke;
    font-size: 35px; 
    margin-top: 100px;
    margin-bottom: 100px;
    margin-right: 150px;
    margin-left: 80px;
    text-align: center;
    font-family: 'Nunito', sans-serif;
  }
 
#me{
    text-align: center;
}
#you{
    text-align: center;
}
p{
    color: white;
    text-align: center;
    font-size: 35px;
    font-family: 'Nunito', sans-serif;
}

/**{
    padding: 100px;
    margin: 100px;
}
.menu-bar{
    background-color: rgb(63, 53, 53);
    text-align: right;
}
.menu-bar ul{
    display: inline-flex;
    list-style: none;
}
.menu-bar ul li a{
    text-decoration: none;
    color:black;
    font-size: 25px; 
    
    margin: 10px;
    padding: 10px;
}
.menu-bar ul li:hover {
    background: rgb(214, 70, 70);

}
.menu-bar .fa{
    margin: 0%;
}*/
/*.fa-chalkboard-teacher{
    color: cornsilk;
}
.fa-phone{
    color: cornsilk;
}
.fa-user-circle{
    color: cornsilk;
}
.fa-flag-checkered{
    color: cornsilk;
}
.fa-microphone-alt{
    color: cornsilk;
}*/
#can{
    width: 150px;
    height: 100px;
    margin-left: auto;
    margin-right: auto;
    background-color: #262626;
}
#a:hover{
    transform: scale(1.3);
}

header{
    position: relative;
    height: 100px;
    background: #262626;
    width: 100%;
    z-index: 12 ;
}
#logo{
    width: 30%;
    float: left;
    margin-left: 20px;
}
#logo a{
    text-decoration: none;
    font-family: 'New Tegomin', serif;
    color: white;
    letter-spacing: 3px;
}
nav{
    float: right;
    line-height: 100px;
    margin-right: 50px;
}
nav a{
    text-decoration: none;
    font-size: 15px;
    font-family: 'Nunito', sans-serif ;
    color: white;
    padding: 10px;
}
nav a:hover{
    background-color: #4e4e50;
    padding-top: 15%;
    padding-bottom:15%;
    padding-inline-start:10px;
    padding-inline-end: 10px;

}

.centerdiv{
        display: flex;
        justify-content: center;
        align-items: flex-start;
    }

    .centerdiv a{
        
        height: 50px;
        width: 50px;
        background-color: #f5f6fa;
        border-radius: 50px;
        text-align: center;
        line-height: 65px;
        margin: 10px;
    -webkit-box-shadow: 0 8px 6px -6px black;
	-moz-box-shadow: 0 8px 6px -6px black;
    box-shadow: 0 8px 6px -6px black;
    }
    a i{
        transition: all 0.3s linear;
    }

    a:hover i{
        transform: scale(1.2);
    }
    .fa-instagarm{
        color: #e84393;
    }
    .fa-facebook{
        color:#3b5998;
    }
    .fa-twitter{
        color:#009796;
    }
    .fa-youtube{
        color: #BB001B;
    }
    .fa-envelope{
        color:#BB001B;
    }
    .fa-linkedin{
        color:#009796;
    }
</style>
<!--<link rel="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">">
<link rel="https://fonts.google.com/specimen/New+Tegomin?query=tegomin">-->
<link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=New+Tegomin&display=swap" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=New+Tegomin&display=swap');
    </style>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Kiwi+Maru:wght@300&family=New+Tegomin&family=Nunito:wght@200&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <script src="https://kit.fontawesome.com/66717420c9.js" crossorigin="anonymous"></script>
</head>
<body>
 
  <!-- Bootstrap CSS -->
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<title>PHP login system!</title>
</head>
<body>-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<a class="navbar-brand" href="#"></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
<ul class="navbar-nav">
  <li class="nav-item active">
    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="register.php">Register</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="login.php">Login</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="logout.php">Logout</a>
  </li>

  
 
</ul>

<div class="navbar-collapse collapse">
<ul class="navbar-nav ml-auto">
<li class="nav-item active">
<a class="nav-link" href="#"><i class="fas fa-user-circle"></i> <?php echo $_SESSION['username']?></a>
  
<!--<a class="nav-link" href="#"> <img src="https://img.icons8.com/metro/26/000000/guest-male.png"> <?php echo "Welcome ". $_SESSION['username']?></a>-->
  </li>
</ul>
</div>


</div>
</nav>

<div class="container mt-4">
<h3><?php echo "Welcome ". $_SESSION['username']?></h3>
<hr>

</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 <!--<div class="menu-bar">
 <ul>-->
      
    <center><div id="logo"></div>
        <a href="homepage.html"><img src="speakup.png" alt=""></a>
    </div></center>
    
    <div class="navig">
        <header>
            <nav>
                <a href="homepage.html" target="_blank">Home</a>
                <a href="https://docs.google.com/forms/d/e/1FAIpQLSfaWuN0YaSwtlTL2oeOybkNFQU3pD_-knmfwfJB537N1y4UOw/viewform?usp=sf_link" target="_blank">Submissions</a>
                <a href="About.html" target="_blank">About</a>
                <a href="speakk.html" target="_blank">Courses</a>
                <a href="Eventpage.html" target="_blank">Events</a>
            </nav>
        </header>
    </div>
<!-- </ul>
</div>-->
<br>
<h1>SPEAK UP</h1> 
 
 <br><br>
 <div>
    <h1 id="you" style="margin-bottom: 50px;">WHAT DO WE OFFER</h1> 
 <img src="https://s3-ap-southeast-1.amazonaws.com/yourdost-blog-images/wp-content/uploads/2017/06/04132602/introvertsartofpublicspeaking-cover-1250x654.jpg">
 <br><br>
 <p class="font">We are here to provide you the exposure of public speaking along with proper guidance through this platform.</p>
 </div><br><br><br><br><br><br>

 
 <!--<h1 id="you">WHAT DO WE OFFER</h1>-->

 
 <h2 style="margin-bottom: 50px;">PUBLIC SPEAKING</h2>
 <figure>

 <img src="https://img.freepik.com/free-photo/woman-speaks-into-microphone-gives-lecture-about-business-conference-training-seminar-business-presentation-audience-meeting_78492-2757.jpg?size=626&ext=jpg">

 <figcaption class="font"> place where you can practice and improve yourself by getting reviews from public</figure> 
</figure>
 

<h2 style="margin-bottom: 50px;">Courses</h2>
<figure>

<img src="https://pbs.twimg.com/media/EF1-hAtX0AAi9u8.jpg">
<figcaption class="font">We'll provide you complete guidance to build up confidence and help you improve your speaking skills through weekly cources</figcaption>
  
</figure> 
<!--<div class="img-with-text">
    <img src="https://img.freepik.com/free-photo/woman-speaks-into-microphone-gives-lecture-about-business-conference-training-seminar-business-presentation-audience-meeting_78492-2757.jpg?size=626&ext=jpg" alt="sometext" />-->
    <!--<p>A place where you can practice and improve yourself by getting reviews from public</p>-->
<!--</div>-->
<!--<div class="img-with-text">
    <img src="https://pbs.twimg.com/media/EF1-hAtX0AAi9u8.jpg" alt="sometext" />-->
    <!--<p>We'll provide you a platform to organize your own event like elocution or debate or extempore competition!</p>-->
<!--</div>--> 
<!--</div>-->

 <h1 style="margin-bottom: 50px;">OBECTIVE</h1>
 <p class="font">SPEAK UP would like you to provide a platform to enhance your speaking skills through our courses and also provide you the facility and opportuniy to practice speaking and getting revievs from people and improving yourself.</p>
 <br>
 <p style="font-size: 25px;">Celebrating the joy of speaking!</p>
 <br><br><br><br><br><br>
 <!--<footer>
    <h1>CONTACT US</h1>


     <h3>Arya Shahi</h3>        <h3>aryashahi2002@gmail.com</h3>        <h3>8141809504</h3>   
    
      
     
     <h3>Priyanshi Shah</h3>       <h3>priyanshipshah19@gmail.com</h3>
         
    <h3>Pakhi Srivastava</h3>       <h3>zenith.pakhi@gmail.com</h3>
    
<div class="centerdiv" id="can">
    <a class="cat" href="https://www.facebook.com/pakhi.srivastava.581" target="_blank">
        <i class="fab fa-facebook fa-7x"></i>
    </a>
    <a class="cat" href="" target="_blank">
    <i class="fab fa-instagram fa-7x"></i>
    </a>
    <a class="cat" href="" target="_blank">
        <i class="fas fa-envelope-open fa-7x"></i>
    </a>
    <a class="cat" href="" target="_blank">
        <i class="fab fa-twitter fa-7x"></i>
    </a>
    <a class="cat" href="" target="_blank">
        <i class="fab fa-youtube fa-7x"></i>
    </a>
</div>


     
 </footer>-->
<div id="footer">
    <p style="font-size: 20px;" id="center">Celebrating the joy of speaking!</p>
    <div class="centerdiv">
        <a href="https://www.facebook.com/All-Projects-Website-105083125055378" target="_blank" class="tu">
            <i class="fab fa-facebook fa-2x"></i>
        </a>
        <a href="https://www.instagram.com/allprojectwebsites/" target="_blank" class="tu">
            <i class="fab fa-instagram fa-2x"></i>
        </a>
        <a href="mailto:allprojectwebsites@gmail.com" target="_blank" class="tu">
            <i class="fas fa-envelope fa-2x"></i>
        </a>
        <a href="https://www.youtube.com/channel/UCE8Hx6-8ucLhtfv0yfwOvaQ" target="_blank" class="tu">
            <i class="fab fa-youtube fa-2x"></i>
        </a>
    </div>
</body>
</html>